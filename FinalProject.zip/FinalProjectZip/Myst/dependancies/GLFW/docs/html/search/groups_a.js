var searchData=
[
  ['window_20reference_775',['Window reference',['../group__window.html',1,'']]]
];
